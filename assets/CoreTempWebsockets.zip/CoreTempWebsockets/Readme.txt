Installation:

1. Create a "plugins" folder in the Core Temp's location.

2. Extract the content of this file into a folder name "CoreTempWebsockets" under "plugins".

3. Make sure that you enable Plugins in Core Temp settings.

4. Run Core Temp.

5. You will have to forward port 5100 to your computer. If you have several machines, most routers enable you to map ports, that way you define a different external port for each machine, something like 5100, 5101, 5102, but internally you always map them to 5100.